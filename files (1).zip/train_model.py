"""Train and evaluate the sign classifier. Saves evidence to results/."""
import os

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             classification_report, confusion_matrix)
from sklearn.model_selection import train_test_split

os.makedirs("results", exist_ok=True)
os.makedirs("models", exist_ok=True)

df = pd.read_csv("data/dataset.csv", header=None)
y = df.iloc[:, 0].astype(str)
X = df.iloc[:, 1:]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

train_acc = accuracy_score(y_train, model.predict(X_train))
pred = model.predict(X_test)
test_acc = accuracy_score(y_test, pred)
report = classification_report(y_test, pred)

summary = (
    f"Total samples : {len(df)}\n"
    f"Classes       : {sorted(y.unique())}\n"
    f"Train samples : {len(X_train)}\n"
    f"Test samples  : {len(X_test)}\n"
    f"Train accuracy: {train_acc:.4f}\n"
    f"Test accuracy : {test_acc:.4f}\n\n{report}"
)
print(summary)
with open("results/training_results.txt", "w") as f:
    f.write(summary)

labels = sorted(y.unique())
cm = confusion_matrix(y_test, pred, labels=labels)
fig, ax = plt.subplots(figsize=(8, 8))
ConfusionMatrixDisplay(cm, display_labels=labels).plot(ax=ax, colorbar=False)
plt.title("Confusion Matrix (test set)")
plt.tight_layout()
plt.savefig("results/confusion_matrix.png", dpi=150)

joblib.dump(model, "models/sign_model.pkl")
print("Saved models/sign_model.pkl and results/")
