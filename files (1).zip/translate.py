"""Real-time sign language translator.

Controls: C = clear text, V = speak text (if pyttsx3 installed), Q = quit.
Saves average FPS and latency to results/live_metrics.txt on exit.
"""
import os
import time
from collections import Counter, deque

import cv2
import joblib
import mediapipe as mp

from utils import extract_features

os.makedirs("results", exist_ok=True)
model = joblib.load("models/sign_model.pkl")

try:
    import pyttsx3
    tts = pyttsx3.init()
except Exception:
    tts = None

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

WINDOW = 10        # frames used for smoothing predictions
HOLD_FRAMES = 15   # stable frames needed to add a letter to the text
recent = deque(maxlen=WINDOW)
text, stable_count, last_added = "", 0, None
latencies, fps_list = [], []

cap = cv2.VideoCapture(0)
prev = time.time()

with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.6,
                    min_tracking_confidence=0.6) as hands:
    while cap.isOpened():
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        result = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

        current = ""
        if result.multi_hand_landmarks:
            hl = result.multi_hand_landmarks[0]
            mp_draw.draw_landmarks(frame, hl, mp_hands.HAND_CONNECTIONS)

            t0 = time.time()
            feats = extract_features(hl).reshape(1, -1)
            recent.append(model.predict(feats)[0])
            latencies.append((time.time() - t0) * 1000)

            current = Counter(recent).most_common(1)[0][0]
            if current == last_added:
                stable_count = 0
            else:
                stable_count += 1
                if stable_count >= HOLD_FRAMES:
                    text += current
                    last_added, stable_count = current, 0
        else:
            recent.clear()
            last_added, stable_count = None, 0

        now = time.time()
        fps = 1 / max(now - prev, 1e-6)
        prev = now
        fps_list.append(fps)

        cv2.putText(frame, f"Sign: {current}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        cv2.putText(frame, f"Text: {text}", (10, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 0), 2)
        cv2.putText(frame, f"FPS: {fps:.1f}", (10, 105),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2)
        cv2.imshow("Sign Language Translator", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        elif key == ord("c"):
            text = ""
        elif key == ord("v") and tts and text:
            tts.say(text)
            tts.runAndWait()

cap.release()
cv2.destroyAllWindows()

if fps_list and latencies:
    metrics = (f"Average FPS: {sum(fps_list) / len(fps_list):.1f}\n"
               f"Average prediction latency (ms): "
               f"{sum(latencies) / len(latencies):.2f}\n"
               f"Frames processed: {len(fps_list)}\n")
    print(metrics)
    with open("results/live_metrics.txt", "w") as f:
        f.write(metrics)
