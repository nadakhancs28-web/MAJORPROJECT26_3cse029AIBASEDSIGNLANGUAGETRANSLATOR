"""Collect training samples from the webcam.

Controls:
  any letter/number key : set the current label (sign)
  SPACE                 : start/stop recording samples for that label
  ESC                   : quit
Samples are appended to data/dataset.csv (label + 63 features).
"""
import csv
import os

import cv2
import mediapipe as mp

from utils import extract_features

os.makedirs("data", exist_ok=True)
CSV_PATH = os.path.join("data", "dataset.csv")

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)
label, recording, count = None, False, 0

with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.6,
                    min_tracking_confidence=0.6) as hands, \
        open(CSV_PATH, "a", newline="") as f:
    writer = csv.writer(f)
    while cap.isOpened():
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)
        result = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

        if result.multi_hand_landmarks:
            hl = result.multi_hand_landmarks[0]
            mp_draw.draw_landmarks(frame, hl, mp_hands.HAND_CONNECTIONS)
            if recording and label:
                writer.writerow([label] + list(extract_features(hl)))
                count += 1

        status = f"Label: {label}  Recording: {recording}  Saved: {count}"
        cv2.putText(frame, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.7, (0, 255, 0), 2)
        cv2.imshow("Collect data", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == 27:
            break
        elif key == 32:
            recording = not recording
            count = 0 if recording else count
        elif key != 255 and chr(key).isalnum():
            label, recording, count = chr(key).upper(), False, 0

cap.release()
cv2.destroyAllWindows()
