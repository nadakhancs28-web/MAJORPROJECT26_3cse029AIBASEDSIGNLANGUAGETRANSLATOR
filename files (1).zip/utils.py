import numpy as np


def extract_features(hand_landmarks):
    """Convert 21 MediaPipe hand landmarks into a 63-value feature vector,
    normalized for hand position (wrist at origin) and hand size (scale)."""
    pts = np.array([[l.x, l.y, l.z] for l in hand_landmarks.landmark])
    pts = pts - pts[0]
    scale = np.max(np.linalg.norm(pts[:, :2], axis=1))
    if scale == 0:
        scale = 1.0
    pts = pts / scale
    return pts.flatten()
