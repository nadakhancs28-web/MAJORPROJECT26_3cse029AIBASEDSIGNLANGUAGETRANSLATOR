# AI-Based Sign Language Translator

Real-time static sign recognition using a webcam, MediaPipe hand landmarks
and a scikit-learn classifier.

## Setup
```
pip install -r requirements.txt
```

## Usage
1. `python collect_data.py`   - record samples for each sign (data/dataset.csv)
2. `python train_model.py`    - train, evaluate, save model and results/
3. `python translate.py`      - live translation to text (and speech)

## Evidence generated
- results/training_results.txt  - accuracy and per-class report
- results/confusion_matrix.png  - confusion matrix on the test set
- results/live_metrics.txt      - average FPS and latency from live run
- models/sign_model.pkl         - trained model

## Pipeline
Webcam -> MediaPipe landmarks -> normalization -> classifier ->
smoothing -> text (and optional text-to-speech)
